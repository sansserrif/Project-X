function signIn() {
    alert("Don't press it because the bomb will explode ");
}

function searchProduct() {
    const searchTerm = document.getElementById('searchInput').value;
    if(searchTerm) {
        alert("Searching for: " + searchTerm);
    } else {
        alert("Please enter a product name!");
    }
}

function productClick(name) {
    alert("You clicked on: " + name);
}